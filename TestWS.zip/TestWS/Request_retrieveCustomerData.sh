#!/bin/bash
num=$1
time curl --trace-time --trace-ascii  Request_retrieveCustomerData_${num}.log -X  POST -d @Requests/Request_retrieveCustomerData.xml                  http://172.24.160.135:8080/SelfServiceMobile_Project/Services/Proxy_Pipelines/AccountManagement_PS >Responses/Response_retrieveCustomerData.xml
