#!/bin/bash
num=$1
time curl --trace-time --trace-ascii Request_retrieveConsumptionDetailInformation_${num}.log -X POST -d @Requests/Request_retrieveConsumptionDetailInformation.xml  http://172.24.160.135:8080/SelfServiceMobile_Project/Services/Proxy_Pipelines/ServiceManagement_PS >Responses/Response_retrieveConsumptionDetailInformation.xml
