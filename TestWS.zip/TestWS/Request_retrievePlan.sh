#!/bin/bash
num=$1
time curl --trace-time --trace-ascii Request_retrievePlan_${num}.log -X POST -d @Requests/Request_retrievePlan.xml                          http://172.24.160.135:8080/SelfServiceMobile_Project/Services/Proxy_Pipelines/ServiceManagement_PS >Responses/Response_retrievePlan.xml
