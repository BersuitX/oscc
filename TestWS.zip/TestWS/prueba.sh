#!/bin/bash
date
script=$1
cnt=1
tests=${2:-10}
secs=${3:-0}

while [ $cnt -le $tests ];
do
 echo "==================== $cnt ====================";
# time curl -v --trace-time -X POST -H "Content-Type: text/xml" --data @${FILER} $URL_WS
 sh $script $cnt
 let cnt++
 sleep $secs
done
date

