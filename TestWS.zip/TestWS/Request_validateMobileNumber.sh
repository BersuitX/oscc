#!/bin/bash
time curl -X POST -d @Requests/Request_validateMobileNumber.xml                  http://172.24.160.135:8080/SelfServiceMobile_Project/Services/Proxy_Pipelines/AccountManagement_PS >Responses/Response_validateMobileNumber.xml
