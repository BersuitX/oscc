#!/bin/bash
num=$1
time curl -v --trace-time --trace-ascii validateNumber_${num}.log -X POST -d @Requests/Request_validateNumber.xml                        http://172.24.160.135:8080/SelfServiceMobile_Project/Services/Proxy_Pipelines/AccountManagement_PS >Responses/Response_validateNumber.xml
