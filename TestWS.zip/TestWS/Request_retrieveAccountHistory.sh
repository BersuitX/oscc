#!/bin/bash
num=$1
time curl --trace-time --trace-ascii Request_retrieveAccountHistory_${num}.log -X POST -d @Requests/Request_retrieveAccountHistory.xml                http://172.24.160.135:8080/SelfServiceMobile_Project/Services/Proxy_Pipelines/AccountManagement_PS >Responses/Response_retrieveAccountHistory.xml
